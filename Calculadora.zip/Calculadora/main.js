$(document).on('click','#igual',function(){
actualiza();


}